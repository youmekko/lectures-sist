package com.test;

public class Scores {

	private String score_id, student_id, student_name, picture;
	private int java, oracle, jsp,  total_score;
	private double java_avg, oracle_avg,jsp_avg;
	public String getScore_id() {
		return score_id;
	}
	public String getStudent_id() {
		return student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public String getPicture() {
		return picture;
	}
	public int getJava() {
		return java;
	}
	public int getOracle() {
		return oracle;
	}
	public int getJsp() {
		return jsp;
	}
	public int getTotal_score() {
		return total_score;
	}
	public double getJava_avg() {
		return java_avg;
	}
	public double getOracle_avg() {
		return oracle_avg;
	}
	public double getJsp_avg() {
		return jsp_avg;
	}
	
	
	public void setScore_id(String score_id) {
		this.score_id = score_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public void setJava(int java) {
		this.java = java;
	}
	public void setOracle(int oracle) {
		this.oracle = oracle;
	}
	public void setJsp(int jsp) {
		this.jsp = jsp;
	}
	public void setTotal_score(int total_score) {
		this.total_score = total_score;
	}
	public void setJava_avg(double java_avg) {
		this.java_avg = java_avg;
	}
	public void setOracle_avg(double oracle_avg) {
		this.oracle_avg = oracle_avg;
	}
	public void setJsp_avg(double jsp_avg) {
		this.jsp_avg = jsp_avg;
	}
	
	
	
}
