package com.test;

import java.sql.*;
import java.util.*;


public class ScoresDAO {

	/* 	private String score_id, student_id, student_name;
		private int attendance_score, writing_score, practice_score;
	 */
	
	public List<Scores> list() {
		List<Scores> result = new ArrayList<Scores>();

		String sql = "SELECT score_id, java, oracle, jsp, java+oracle+jsp AS total_score, student_id, student_name, picture FROM scores";

		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = MySQLConnection.connect();

			pstmt = conn.prepareStatement(sql);

			
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				String score_id = rs.getString("score_id");
				int java = rs.getInt("java");
				int oracle = rs.getInt("oracle");
				int jsp = rs.getInt("jsp");
				int total_score = rs.getInt("total_score");
				String student_id = rs.getString("student_id");
				String student_name = rs.getString("student_name");
				String picture = rs.getString("picture");

				Scores m = new Scores();
				m.setScore_id(score_id);
				m.setJava(java);
				m.setOracle(oracle);
				m.setJsp(jsp);
				m.setTotal_score(total_score);
				m.setStudent_id(student_id);
				m.setStudent_name(student_name);
				m.setPicture(picture);
				result.add(m);

			}
			rs.close();

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException se) {
			}
			try {
				MySQLConnection.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return result;

	}
	
	public List<Scores> list(String student_id) {
		List<Scores> result = new ArrayList<Scores>();

		String sql = "SELECT score_id, java, oracle, jsp, java+oracle+jsp AS total_score, (SELECT ROUND(AVG(java),2) FROM scores) AS java_avg,  (SELECT ROUND(AVG(oracle),2) FROM scores) AS oracle_avg,(SELECT ROUND(AVG(jsp),2) FROM scores) AS jsp_avg, student_id, student_name, picture FROM scores WHERE student_id=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = MySQLConnection.connect();

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, student_id);
			
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				String score_id = rs.getString("score_id");
				int java = rs.getInt("java");
				int oracle = rs.getInt("oracle");
				int jsp = rs.getInt("jsp");
				double java_avg = rs.getDouble("java_avg");
				double oracle_avg = rs.getDouble("oracle_avg");
				double jsp_avg = rs.getDouble("jsp_avg");
				int total_score = rs.getInt("total_score");
				String student_name = rs.getString("student_name");
				String picture = rs.getString("picture");

				Scores m = new Scores();
				m.setScore_id(score_id);
				m.setStudent_id(student_id);
				m.setJava(java);
				m.setOracle(oracle);
				m.setJsp(jsp);
				m.setJava_avg(java_avg);
				m.setOracle_avg(oracle_avg);
				m.setJsp_avg(jsp_avg);
				m.setTotal_score(total_score);
				m.setStudent_name(student_name);
				m.setPicture(picture);
				result.add(m);

			}
			rs.close();

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException se) {
			}
			try {
				MySQLConnection.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return result;

	}
	
}
